# WhatsApp Message Sender - Design Guidelines

## Design Approach
**System-Based Approach**: Material Design principles adapted for a utility-focused messaging tool. This is a functional dashboard requiring clarity, immediate status visibility, and efficient form interaction.

## Layout Architecture

**Single-Page Dashboard Layout**
- No hero section - this is a tool, not a marketing page
- Centered card-based interface with max-width of 600px
- Full viewport height with centered vertical alignment
- Main container: bg-white shadow-lg rounded-lg with p-8 padding
- Use tailwind spacing units: 2, 4, 6, and 8 consistently throughout

**Vertical Flow Structure**
1. Header section with app title and branding (mb-6)
2. Connection status indicator (mb-8)
3. Message form with clear field grouping (space-y-6)
4. Action button area (mt-8)
5. Feedback/response area (mt-6)

## Typography System

**Font Selection**: Use Inter or Roboto via Google Fonts CDN

**Hierarchy**:
- App Title: text-3xl font-bold tracking-tight
- Section Headers: text-lg font-semibold
- Labels: text-sm font-medium uppercase tracking-wide
- Input Text: text-base
- Status Messages: text-sm
- Helper Text: text-xs

## Component Specifications

### Connection Status Banner
- Full-width alert component at top of card
- Two states: Connected (success state) / Disconnected (warning state)
- Include status icon (use Heroicons CDN) + status text + timestamp
- Prominent positioning with rounded-lg and p-4 padding
- Animated pulse effect on "Connecting..." state

### Form Layout
**Phone Number Input**:
- Label above input with mb-2
- Input field: full width, h-12, rounded-md border
- Placeholder: "+1234567890 (with country code)"
- Helper text below: "Include country code (e.g., +1 for US)"

**Message Textarea**:
- Label above with mb-2
- Textarea: full width, h-32, rounded-md border
- Placeholder: "Type your message here..."
- Character counter below (text-xs, text-right)
- Max characters display: "0 / 1000"

**Field Spacing**: space-y-6 between form groups

### Action Button
- Primary button: full width, h-12, rounded-md
- Text: "Send Message" with send icon (Heroicons paper-airplane)
- Icon positioned to right of text with ml-2
- Disabled state when not connected
- Font: text-base font-semibold

### Feedback Area
- Response message card below button
- Success: includes checkmark icon + "Message sent successfully!"
- Error: includes exclamation icon + error details
- Animated slide-in from bottom (fade + translate)
- Auto-dismiss after 5 seconds

## Additional UI Elements

### Loading States
- Button: Show spinner icon replacing send icon when processing
- Button text changes to "Sending..."
- Disable form inputs during send operation

### Empty State (Not Connected)
- Large icon (Heroicons qr-code) centered
- Primary text: "WhatsApp Not Connected"
- Secondary text: "Scan QR code in console to connect"
- Muted visual treatment for entire form

### Mobile Responsiveness
- Desktop: max-w-2xl centered container
- Mobile: p-4 instead of p-8, full-width with 16px margins
- Form inputs maintain full width
- Button remains full width on all screens

## Spacing & Rhythm
- Container padding: p-8 (desktop), p-4 (mobile)
- Section spacing: mb-6 to mb-8 for major sections
- Form field spacing: space-y-6
- Input internal padding: px-4 py-3
- Consistent border-radius: rounded-md (6px) for all interactive elements

## Icons
Use Heroicons via CDN (outline style):
- Status: check-circle (success), exclamation-triangle (warning)
- Actions: paper-airplane (send), arrow-path (loading)
- States: qr-code (not connected), wifi (connected)

## Accessibility
- All inputs have associated labels with htmlFor attributes
- ARIA labels on status indicators
- Focus states: ring-2 ring-offset-2 on all interactive elements
- Keyboard navigation: proper tab order through form
- Error messages linked to inputs via aria-describedby

## Visual Hierarchy Principles
- Status visibility: Most prominent element when disconnected
- Form clarity: Clear labels, generous spacing, obvious focus states
- Action prominence: Send button stands out but only when enabled
- Feedback immediacy: Success/error messages appear in predictable location

**No Images Required** - This is a functional tool interface; icons provide sufficient visual communication.