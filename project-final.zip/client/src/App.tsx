import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import Home from "@/pages/home";
import BulkSend from "@/pages/bulk-send";
import ApiKeys from "@/pages/api-keys";
import Documentation from "@/pages/documentation";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import { useEffect, useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/bulk-send" component={BulkSend} />
      <Route path="/api-keys" component={ApiKeys} />
      <Route path="/docs" component={Documentation} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  useEffect(() => {
    const auth = localStorage.getItem("app_authenticated");
    setIsAuthenticated(auth === "true");
    setIsCheckingAuth(false);
  }, []);

  useEffect(() => {
    const keepAlive = async () => {
      try {
        const replUrl = window.location.origin;
        console.log(`Keep-alive: Visiting server at ${replUrl}`);
        
        await fetch('/api/visit', { method: 'POST' });

        const keepAlivePhone = localStorage.getItem('keep_alive_phone') || '201200000000';
        
        if (keepAlivePhone) {
          console.log(`Keep-alive: Sending message to ${keepAlivePhone}`);
          const response = await fetch('/api/send-direct', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              number: keepAlivePhone,
              message: `زيارة تلقائية للسيرفر في ${new Date().toLocaleString('ar-EG')}`
            })
          });

          const data = await response.json();
          if (data.success) {
            console.log('Keep-alive: Message sent successfully');
          } else {
            console.error('Keep-alive: Failed to send message:', data.error);
          }
        }
      } catch (error) {
        console.log('Keep-alive error:', error);
      }
    };

    keepAlive();
    const interval = setInterval(keepAlive, 3 * 60 * 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        {isCheckingAuth ? null : !isAuthenticated ? (
          <>
            <Login onLogin={() => setIsAuthenticated(true)} />
            <Toaster />
          </>
        ) : (
          <>
            <SidebarProvider style={style as React.CSSProperties}>
              <div className="flex h-screen w-full">
                <AppSidebar />
                <div className="flex flex-col flex-1 overflow-hidden">
                  <header className="flex items-center gap-2 p-4 border-b">
                    <SidebarTrigger data-testid="button-sidebar-toggle" />
                    <h1 className="text-sm font-medium">WhatsApp Message API</h1>
                  </header>
                  <main className="flex-1 overflow-auto">
                    <Router />
                  </main>
                </div>
              </div>
            </SidebarProvider>
            <Toaster />
          </>
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
